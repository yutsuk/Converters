package C7227233;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.NoSuchElementException;

import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.UIManager;

/*
@author Utsuk Paudayal
 Student ID(LEEDS): 77227233
*/

/*
 * creating and declaring all the needed variables that are used for making the
 * converter.
 */
public class Currency extends JPanel {
	public final static String[] currency = { "British Pound/Japanese yen", "British Pound/Euro",
			"British Pound/US Dollars", "British Pound/Australian Dollars", "British Pound/Canadian Dollars",
			"British Pound/South Korean Won", "British Pound/Thai Baht", "British Pound/UAE Dirham" };

	public static JComboBox<String> currencyList;
	public static JTextField userInput, conversionResult;
	public static JLabel enter, counter;
	public JButton convertButton;
	private JButton clearButton;
	public JCheckBox reverse;
	boolean number = true;
	String answer, fileLoc, symbol, line;
	static int count = 0;
	static String text2;
	int lines = 0;

	String[] currencyName = new String[100];
	double[] currencyRate = new double[100];
	String[] currencySymbol = new String[100];
	String[] lineChecker;

	JMenuBar setupMenu() {

		ActionListener listener = new uploadListener();

		// creating a new menuBar named menu and adding bg color orange.
		JMenuBar menu = new JMenuBar();
		menu.setBackground(Color.orange);

		JMenu file = new JMenu("File"); // creating a menu option named file.
		file.setMnemonic('f'); // assigning shortcut key "f" for menu and opens file when ALT+f is pressed.
		menu.add(file); // adding menu option file in the menuBar.
		file.setToolTipText("Menu item with exit submenu.");

		JMenu help = new JMenu("Help"); // creating a menu option named help.
		help.setMnemonic('h'); // assigning shortcut key "h" for menu and opens help when ALT+h is pressed.
		menu.add(help); // adding menu option help in the menuBar.
		help.setToolTipText("Menu item with about submenu.");

		JMenuItem fileSubMenu1 = new JMenuItem("Load"); // creating a submenuitem named exit.
		file.add(fileSubMenu1); /*
								 * adding the menuitem load in file and when file is clicked we can see load as
								 * its submenu
								 */
		fileSubMenu1.addActionListener(listener);
		
		/*
		 * adding shortcut "l" for load and using setAccelerator in order to execute the
		 * shortcut directly without poping out the menu option when ALT + l is pressed.
		 */
		fileSubMenu1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, KeyEvent.ALT_DOWN_MASK));
		fileSubMenu1.setIcon(new ImageIcon("images/loadFile.jpg")); // setting up an icon for exit menuitem.
		fileSubMenu1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lines = 0;

			}
		});

		JMenuItem fileSubMenu = new JMenuItem("Exit"); // creating a menuitem named exit.
		fileSubMenu.setToolTipText("Click to exit or press alt + e");
		file.add(fileSubMenu); /*
								 * adding the menuitem exit in file and when file is clicked we can see exit as
								 * its submenu
								 */
		fileSubMenu.setIcon(new ImageIcon("images/exit.png")); // setting up an icon for exit menuitem.

		/*
		 * adding shortcut "e" for exit and using setAccelerator in order to execute the
		 * shortcut directly without poping out the menu option when ALT + e is pressed.
		 */
		fileSubMenu.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, KeyEvent.ALT_DOWN_MASK));
		fileSubMenu.addActionListener(new ActionListener() { /*
																 * when menuitem exit is clicked the actionListener will
																 * help to perform the given action
																 */
			public void actionPerformed(ActionEvent exit) {
				System.exit(0); /*
								 * it helps you to exit from the panel when menuitem exit is clicked or shortcut
								 * is pressed.
								 */
			}
		});

		JMenuItem helpSubMenu = new JMenuItem("About"); // creating a menuitem named about.
		helpSubMenu.setToolTipText("Click to see the authors detail or press alt + a");
		help.add(helpSubMenu); /*
								 * adding the menuitem about in help menu option and when help is clicked we can
								 * see about as its submenu
								 */
		helpSubMenu.setIcon(new ImageIcon("images/about.png")); // setting up an icon for about menuitem.

		/*
		 * adding shortcut "a" for exit and using setAccelerator in order to execute the
		 * shortcut directly without poping out the menu option when ALT + a is pressed.
		 */
		helpSubMenu.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.ALT_DOWN_MASK));
		helpSubMenu.addActionListener(new ActionListener() { /*
																 * when menuitem exit is clicked the actionListener will
																 * help to perform the given action
																 */
			public void actionPerformed(ActionEvent about) {
				new UIManager(); // UIManager is used here to customize the JOptionPane
				UIManager.put("OptionPane.background", Color.cyan); // changes JOptionPane bg to cyan
				UIManager.put("Panel.background", Color.cyan); // changes panel bg to cyan
				JOptionPane.showMessageDialog(null,
						" Author: Utsuk Paudayal. \n\n Utsuk's converter is used for doing various currency conversions. \n In this converter you can convert many currencies like Euro, US Dollars, Thai Baht and many more. \n This application is made for assignment purpose only. \n Some shortcuts: \n ALT + F: For file menu \n ALT + L: Load files \n ALT + E: Exit from program \n ALT + A: About Application \n\n \u00a9 Copyright 2020. All rights reserved.",
						"About", JOptionPane.INFORMATION_MESSAGE); // displays the msg set by user as information
																	// message.
			}
		});

		return menu;
	}

	Currency() {
		ActionListener listener = new ContverListener();
		
		/*
		 * JComboBox is a swing component which lets the user choose one of several
		 * choices from the dropdown list.
		 */
		currencyList = new JComboBox<String>(currency); 

		enter = new JLabel("Enter amount:"); // creates a JLabel object named enter having some string msg
		
		convertButton = new JButton("Convert"); // creates JButton as convertButton.
		convertButton.addActionListener(listener); // convert values when converButton is pressed.
		convertButton.setToolTipText("Click to convert the amount you entered into conversion option you choose.");

		conversionResult = new JTextField(5); // creates a JTextField object as conversionResult.
		conversionResult.setBackground(Color.LIGHT_GRAY); // giving bg color of JTextField

		userInput = new JTextField(5);
		userInput.addActionListener(listener);
		userInput.setBackground(Color.LIGHT_GRAY);
		userInput.setToolTipText("Enter any amount you want to convert.");

		counter = new JLabel(); // creates a JLabel object as counter.

		clearButton = new JButton("Clear");
		clearButton.addActionListener(listener);
		clearButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				currencyList.setSelectedIndex(0); // goes to Japanese yen when clear is clicked

				userInput.setText(null); // values in userInput will change to null when clear is clicked
				userInput.setBackground(Color.LIGHT_GRAY);
				userInput.grabFocus(); // userInput will be active when clear is clicked.

				conversionResult.setText(null);
				conversionResult.setBackground(Color.LIGHT_GRAY);

				reverse.setSelected(false); // if reverse is selceted then it will be inactive when clear is clicked.
				reverse.setOpaque(false);

				counter.setText(null);

			}
		});

		reverse = new JCheckBox("Reverse");
		reverse.setOpaque(false); // matches reverse area with background of panel.

		// adding above created objects and arranging in order.
		add(currencyList);
		add(enter);
		add(userInput);
		add(convertButton);
		add(conversionResult);
		add(reverse);
		add(clearButton);
		add(counter);
		setPreferredSize(new Dimension(800, 100));
		setBackground(Color.orange);
	}

	private class uploadListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent abc) {

			JFileChooser fileChooser = new JFileChooser(); // creating filechooser for uploading files.
			fileChooser.showOpenDialog(null);
			try {

				fileLoc = fileChooser.getSelectedFile().getAbsolutePath();
			} catch (NullPointerException exn) {
			}
			try {

				BufferedReader buffer = new BufferedReader(new InputStreamReader(new FileInputStream(fileLoc), "UTF8"));
				currencyList.removeAllItems();

				// if uploaded file meets the criteria then following will execute.
				while ((line = buffer.readLine()) != null) {
					lineChecker = line.split(",");
					if (lineChecker.length == 3) { 

						try {
							// checks every lines of the uploaded file.
							currencyRate[lines] = Double.parseDouble(lineChecker[1]);
							currencyName[lines] = lineChecker[0];
							currencySymbol[lines] = lineChecker[2];
							currencyList.insertItemAt(currencyName[lines], lines);
							lines++;

						} catch (Exception error) { // and if not met the criteria then following error will popup.

							JOptionPane.showMessageDialog(null,
									"Sorry, there are some errors in the file you selected");
							JOptionPane.showMessageDialog(null,
									" 1 currency can be converted. \n Please check the available currency options.");

						}
					}
				}

				buffer.close();
			} catch (IOException ex) {

			} catch (NoSuchElementException exception) {
				JOptionPane.showMessageDialog(null, "Your File is Invalid", "Error:", JOptionPane.INFORMATION_MESSAGE);
			} catch (NullPointerException npe) {

			}

		}

	}

	private class ContverListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			if (lines == 0) {
				text2 = userInput.getText().trim();
				number = true;
				if (text2.isEmpty() == false) {
					double value = 0;
					try {
						value = Double.parseDouble(text2);
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(null, "Please input the numeric value", "Error:",
								JOptionPane.INFORMATION_MESSAGE);
						number = false;
					}
					// the factor applied during the conversion
					double factor = 0;

					// if reverse is not checked
					if (reverse.isSelected() == false) {
						switch (currencyList.getSelectedIndex()) {
						case 0:
							factor = 137.52;
							symbol = "¥";
							break;
						case 1:
							factor = 1.09;
							symbol = "€";
							break;
						case 2:
							factor = 1.29;
							symbol = "$";
							break;
						case 3:
							factor = 1.78;
							symbol = "A$";
							break;
						case 4:
							factor = 1.70;
							symbol = "C$";
							break;
						case 5:
							factor = 1537.75;
							symbol = "₩";
							break;
						case 6:
							factor = 40.52;
							symbol = "฿";
							break;
						case 7:
							factor = 4.75;
							symbol = "د.إ";
							break;
						}
					}

					//if reverse is done
					if (reverse.isSelected() == true) {
						symbol = "£";
						switch (currencyList.getSelectedIndex()) {
						case 0:
							factor = 1 / 137.52;
							break;
						case 1:
							factor = 1 / 1.09;
							break;
						case 2:
							factor = 1 / 1.29;
							break;
						case 3:
							factor = 1 / 1.78;
							break;
						case 4:
							factor = 1 / 1.70;
							break;
						case 5:
							factor = 1 / 1537.75;

						case 6:
							factor = 1 / 40.52;
							break;
						case 7:
							factor = 1 / 4.75;
							break;

						}
					}
					double result = factor * value;
					DecimalFormat dec = new DecimalFormat("#.##"); // to show two decimal places
					answer = dec.format(result);
					conversionResult.setText(symbol + answer);
				} else if (text2.isEmpty() == true && event.getSource() == (convertButton)) { //if userInput is empty and convert is clicked
					JOptionPane.showMessageDialog(null, "Please input. \nCannot be empty", "Error:", JOptionPane.INFORMATION_MESSAGE);

				}
				if ((event.getSource() == (convertButton) || event.getSource() == (reverse)
						|| event.getSource() == (currencyList) || event.getSource() == (userInput))
						&& text2.isEmpty() == false && number == true) {
					count++;
					counter.setText("Conversion count: " + count);

				}

			} else if (lines != 0) {

				text2 = userInput.getText().trim();
				if (text2.isEmpty() == false) {
					double value = 0;
					try {
						value = Double.parseDouble(text2);
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(null, "Please input the numeric value", "Error:",
								JOptionPane.INFORMATION_MESSAGE);
						number = false;
					}
					// the factor applied during the conversion
					double factor = 0;

					if (reverse.isSelected() == false) {
						for (int i = 0; i < 100; i++) {
							if (currencyList.getSelectedItem() == currencyName[i]) {
								symbol = currencySymbol[i];
								factor = currencyRate[i];
							}
						}
					}
					if (reverse.isSelected() == true) {
						for (int i = 0; i < 100; i++) {
							if (currencyList.getSelectedItem() == currencyName[i]) {
								symbol = "£";
								factor = 1 / currencyRate[i];
							}
						}
					}

					double result = factor * value;
					DecimalFormat dec = new DecimalFormat("#.##");
					answer = dec.format(result);
					conversionResult.setText(symbol + answer);
				} else if (text2.isEmpty() == true && event.getSource() == convertButton) {
					JOptionPane.showMessageDialog(null, "Please input the value", "Error:",
							JOptionPane.INFORMATION_MESSAGE);

				}

				if ((event.getSource() == (convertButton) || event.getSource() == (reverse)
						|| event.getSource() == (currencyList) || event.getSource() == (userInput))
						&& text2.isEmpty() == false && number == true) {
					count++;
					counter.setText("Conversion count:" + count);

				}
			}
		}
	}
}
