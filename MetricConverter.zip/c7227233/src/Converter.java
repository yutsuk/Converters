
import javax.swing.ImageIcon;
import javax.swing.JFrame;

/**
 * The main driver program for the GUI based conversion program.
 * 
 * @author mdixon
 * 
 * Name : Utsuk Paudayal 
 * StudentID(Leeds): 77227233
 */
public class Converter {

	public static void main(String[] args) {

		JFrame frame = new JFrame("Utsuk's Converter"); // create JFrame object name as frame.
		ImageIcon icon = new ImageIcon("image/logo.png"); // adding icon for converter.
		frame.setIconImage(icon.getImage());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // if close is pressed then program exit.

		MainPanel panel = new MainPanel(); // create MainPanel object name as panel.

		frame.setJMenuBar(panel.setupMenu()); // add panel to the frame with menubar.
		frame.getContentPane().add(panel);
		
		frame.pack(); //sizes the frame so that all its contents are in prefered size.
		frame.setLocationRelativeTo(null); //the panel is centered on the screen.
		frame.setResizable(false); // cannot resize(maximize) the panel.
		frame.setVisible(true);

	}
}
