import java.awt.Color; //import Color class from the java swing GUI library.
import java.awt.Dimension; //import Dimension class from the java swing GUI library.
import java.awt.event.ActionEvent; //import ActionEvent class from the java swing GUI library.
import java.awt.event.ActionListener; //import ActionListener class from the java swing GUI library.
import java.awt.event.KeyAdapter; //import KeyAdapter class from the java swing GUI library.
import java.awt.event.KeyEvent; //import KeyEvent class from the java swing GUI library.
import java.text.DecimalFormat; //import DecimalFormat class from the java swing GUI library.

import javax.swing.ImageIcon; //import ImageIcon class from the java swing GUI library.
import javax.swing.JButton; //import JButton class from the java swing GUI library.
import javax.swing.JCheckBox; //import JCheckBox class from the java swing GUI library.
import javax.swing.JComboBox; //import JComboBox class from the java swing GUI library.
import javax.swing.JLabel; //import JLabel class from the java swing GUI library.
import javax.swing.JMenu; //import JMenu class from the java swing GUI library.
import javax.swing.JMenuBar; //import JMenuBar class from the java swing GUI library.
import javax.swing.JMenuItem; //import JMenuItem class from the java swing GUI library.
import javax.swing.JOptionPane; //import JOptionPane class from the java swing GUI library.
import javax.swing.JPanel; //import JPanel class from the java swing GUI library.
import javax.swing.JTextField; //import JTextField class from the java swing GUI library.
import javax.swing.KeyStroke; //import KeyStroke class from the java swing GUI library.
import javax.swing.UIManager; //import UIManager class from the java swing GUI library.

/**
 * The main graphical panel used to display conversion components.
 * 
 * @author mdixon
 * 
 *         Name : Utsuk Paudayal /// StudentID(Leeds): 77227233
 */
@SuppressWarnings("serial")
public class MainPanel extends JPanel {

	/*
	 * creating and declaring all the needed variables that are used for making the
	 * converter.
	 */

	private final static String[] list = { "inches/cm", "Pounds/Kilograms", "Degrees/Radians", "Acres/Hectares",
			"Miles/Kilometres", "Yards/Metres", "Celsius/Fahrenheit" };
	private JTextField textField;
	private JLabel conversionResult;
	private JComboBox<String> conversionTypes;
	private JLabel inputValue, conversionCounter;
	private JButton convertButton, clearButton;
	private JCheckBox reverse;
	private int count = 0;

	JMenuBar setupMenu() {

		// creating a new menuBar named menu and adding bg color orange.
		JMenuBar menu = new JMenuBar();
		menu.setBackground(Color.orange);

		JMenu file = new JMenu("File"); // creating a menu option named file.
		file.setMnemonic('f'); // assigning shortcut key "f" for menu and opens file when ALT+f is pressed.
		menu.add(file); // adding menu option file in the menuBar.
		file.setToolTipText("Menu item with exit submenu.");

		JMenu help = new JMenu("Help"); // creating a menu option named help.
		help.setMnemonic('h'); // assigning shortcut key "h" for menu and opens help when ALT+h is pressed.
		menu.add(help); // adding menu option help in the menuBar.
		help.setToolTipText("Menu item with about submenu.");

		JMenuItem fileSubMenu = new JMenuItem("Exit"); // creating a menuitem named exit.
		fileSubMenu.setToolTipText("Click to exit or press alt + e");
		file.add(fileSubMenu); /*
								 * adding the menuitem exit in file and when file is clicked we can see exit as
								 * its submenu
								 */
		fileSubMenu.setIcon(new ImageIcon("image/exit.png")); // setting up an icon for exit menuitem.

		/*
		 * adding shortcut "e" for exit and using setAccelerator in order to execute the
		 * shortcut directly without poping out the menu option when ALT + e is pressed.
		 */
		fileSubMenu.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, KeyEvent.ALT_DOWN_MASK));
		fileSubMenu.addActionListener(new ActionListener() { /*
																 * when menuitem exit is clicked the actionListener will
																 * help to perform the given action
																 */
			public void actionPerformed(ActionEvent exit) {
				System.exit(0); /*
								 * it helps you to exit from the panel when menuitem exit is clicked or shortcut
								 * is pressed.
								 */
			}
		});

		JMenuItem helpSubMenu = new JMenuItem("About"); // creating a menuitem named about.
		helpSubMenu.setToolTipText("Click to see the authors detail or press alt + a");
		help.add(helpSubMenu); /*
								 * adding the menuitem about in help menu option and when help is clicked we can
								 * see about as its submenu
								 */
		helpSubMenu.setIcon(new ImageIcon("image/about.png")); // setting up an icon for about menuitem.

		/*
		 * adding shortcut "a" for exit and using setAccelerator in order to execute the
		 * shortcut directly without poping out the menu option when ALT + a is pressed.
		 */
		helpSubMenu.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.ALT_DOWN_MASK));
		helpSubMenu.addActionListener(new ActionListener() { /*
																 * when menuitem exit is clicked the actionListener will
																 * help to perform the given action
																 */
			public void actionPerformed(ActionEvent about) {
				new UIManager(); // UIManager is used here to customize the JOptionPane
				UIManager.put("OptionPane.background", Color.cyan); // changes JOptionPane bg to cyan
				UIManager.put("Panel.background", Color.cyan); // changes panel bg to cyan
				JOptionPane.showMessageDialog(null,
						" Author: Utsuk Paudayal. \n\n Utsuk's converter is used for doing various metric conversions. \n This application is made for assignment purpose only. \n\n \u00a9 Copyright 2020. All rights reserved.",
						"About", JOptionPane.INFORMATION_MESSAGE); // displays the msg set by user as information
																	// message.
			}
		});

		return menu;
	}

	// constructor
	MainPanel() {

		ActionListener listener = new ConvertListener();

		/*
		 * JComboBox is a swing component which lets the user choose one of several
		 * choices from the dropdown list.
		 */
		conversionTypes = new JComboBox<String>(list); // create object conversionTypes which has some values in it.
		add(conversionTypes); // adding conversionTypes in mainPanel.
		conversionTypes.setToolTipText("Click to see and choose conversion options.");

		/*
		 * JLabel is a class of java Swing which is used to display a short string or an
		 * image icon.
		 */
		inputValue = new JLabel("Enter a number:"); // creates a JLabel object named inputValue having some string msg.
		add(inputValue); // adding inputValue in mainPanel.

		// TextField is a component that allows editing of a single line of text.
		textField = new JTextField(8); // creates a JTextField object as textField.

		/*
		 * adding KeyListener to textField for some actions when the choosen key is
		 * pressed
		 */
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent enter) {
				if (enter.getKeyCode() == KeyEvent.VK_ENTER)
					convertButton.doClick(); // whne enter is pressed conversion will take place.
			}
		});
		textField.setToolTipText("Input value you wish to convert");
		textField.setBackground(Color.LIGHT_GRAY); // sets the bg color of texfield to light_gray.
		add(textField); // adding textField in mainPanel.

		convertButton = new JButton("Convert"); // creates JButton as convertButton.
		convertButton.addActionListener(listener); // convert values when converButton is pressed.
		add(convertButton); // adding convertButton in mainPanel.
		convertButton.setToolTipText("Click to convert the value you entered into conversion option you choose.");

		conversionResult = new JLabel("- - -"); // creates a JLabel object named conversionResult.
		conversionResult.setBackground(Color.LIGHT_GRAY); // sets the bg color of JLabel(conversionResult) to lightGray.
		add(conversionResult); // adding conversionResult in mainPanel.
		conversionResult.setToolTipText("Converted value.");

		reverse = new JCheckBox("Reverse"); // creates JCheckBox as reverse.
		reverse.setMnemonic('r'); /*
									 * setting shortcut 'r' to reverse. if alt + r is pressed, reverse will be
									 * selected.
									 */

		reverse.setOpaque(false); // reverse checkbox will match ta bg color ko mainpanel.
		add(reverse); // adding reverse in mainPanel.
		reverse.setToolTipText("Click to reverse the conversion option.");

		clearButton = new JButton("Clear"); // creates JButton as clearButton.
		clearButton.setMnemonic('c'); // setting shortcut 'c' to clear. if alt+c is pressed, clear will be selected.
		add(clearButton); // adding cleaButton in mainPanel.
		clearButton.setToolTipText("Click to clear everthing and set it back to normal.");

		// adding clearButton to ActionListener to perform the given action.
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				conversionTypes.setSelectedIndex(0); // goes to inches/cm when clear is clicked
				textField.setText(null); // values in textField will change to null when clear is clicked
				textField.setBackground(Color.LIGHT_GRAY);
				textField.grabFocus(); // textField will be active when clear is clicked.
				conversionResult.setText("- - -");
				conversionResult.setBackground(Color.LIGHT_GRAY);
				reverse.setSelected(false); // if reverse is selceted then it will be inactive when clear is clicked.
				conversionCounter.setText("Conversion Count : 0");
				count = 0; // count goes back to zero(0).

			}
		});

		conversionCounter = new JLabel("Conversion Count : 0"); // creates JLabel as conversionCounter.
		conversionCounter.setToolTipText("Records how many times convert button clicked.");
		add(conversionCounter); // adding conversionCounter in mainPanel.

		setPreferredSize(new Dimension(800, 80)); // sets the size of panel.
		setBackground(Color.ORANGE); // setting bg of panel to orange.
	}

	private class ConvertListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {

			// conversion process

			String text = textField.getText().trim(); // trim textField data by removing space.

			try {

				// if textField isn't empty then the following code will execute
				if (text.isEmpty() == false) {

					double value = Double.parseDouble(text); // text is set to double datatype and assigned to value.

					// the factor applied during the conversion
					double factor = 0;

					// the offset applied during the conversion.
					double offset = 0;

					// Setup the correct factor/offset values depending on required conversion
					switch (conversionTypes.getSelectedIndex()) {

					case 0: // inches/cm
						if (!reverse.isSelected()) { // if reverse is not selected,factor value is set to 2.54
							factor = 2.54;
						} else { // if reverse is selected, factor value is (1/2.54)
							factor = (1 / 2.54);
						}
						break;
					case 1:// Pounds/Kilograms
						if (!reverse.isSelected()) { // if reverse is not selected, factor value is set to (1/2.205)
							factor = (1 / 2.205);
						} else { // if reverse is selected, factor value is (2.205)
							factor = 2.205;
						}
						break;

					case 2: // Degrees/Radians
						if (!reverse.isSelected()) { // if reverse is not selected, factor value is set to (Math.PI/180)
							factor = (Math.PI / 180);
						} else { // if reverse is selected, factor value is (180/ Math.PI)
							factor = (180 / Math.PI);
						}
						break;

					case 3: // Acres/Hectares
						if (!reverse.isSelected()) { // if reverse is not selected, factor value is set to (1/2.471)
							factor = (1 / 2.471);
						} else { // if reverse is selected, factor value is (2.471)
							factor = 2.471;
						}
						break;

					case 4: // Miles/Kilometres

						if (!reverse.isSelected()) { // if reverse is not selected, factor value is set to 1.609
							factor = 1.609;
						} else { // if reverse is selected, factor value is (1/1.609)
							factor = (1 / 1.609);
						}
						break;

					case 5: // Yards/Metres
						if (!reverse.isSelected()) { // if reverse is not selected, factor value is set to (1/1.094)
							factor = (1 / 1.094);
						} else { // if reverse is selected, factor value is (1.094)
							factor = 1.094;
						}
						break;

					case 6: // Celsius/Fahrenheit
						if (!reverse.isSelected()) { // if reverse is not selected, factor value is 1.8 & offset is 32
							factor = 1.8;
							offset = 32;
						} else { // if reverse is selected, factor is (1/1.8) and offset is (-32/1.8)
							factor = (1 / 1.8);
							offset = (-32 / 1.8);
						}
						break;
					}

					// Formula for conversion and assigning the value to result of double datatype.
					double result = factor * value + offset;

					DecimalFormat decimal = new DecimalFormat("#.##"); // only 2 decimal digits after the dot.

					// Set result value in conversionResult as decimal format.
					conversionResult.setText(decimal.format(result));

					count++; // count increases as convert button is clicked.

					// records conversion count.
					conversionCounter.setText("Conversion Counter : " + Integer.toString(count));

				} else {
					// if textField is empty then msg in JOptionPane is displayed as error message.
					new UIManager();
					UIManager.put("OptionPane.background", Color.red);
					UIManager.put("Panel.background", Color.red);
					JOptionPane.showMessageDialog(null, "Cannot be empty. Please enter a number.", "!!! Error !!!",
							JOptionPane.ERROR_MESSAGE);
				}
			} catch (NumberFormatException error) { // checks whether the input value is letters or number.
				new UIManager();
				UIManager.put("OptionPane.background", Color.red);
				UIManager.put("Panel.background", Color.red);

				/*
				 * if input value is not between 0 to 9, then the msg will be displayed as error
				 * message.
				 */
				JOptionPane.showMessageDialog(null, " Error !! \n Please enter a number between 0 to 9 only.",
						"Invalid Input", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
}